<?php

namespace MagicAI_WooCommerce_Extension\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Actions {
	public function __construct() {
		add_action( 'init', [ $this, 'add_to_cart' ] );
	}

	function add_to_cart() {
		if ( ! isset( $_GET['magicai-add-to-cart'] ) || ! class_exists( 'WooCommerce' ) ) {
			return;
		}

		$items = explode( ',', $_GET['magicai-add-to-cart'] );
		foreach ( $items as $item ) {
			list( $product_id, $quantity ) = array_pad( explode( ':', $item ), 2, 1 );
			$product_id = intval( $product_id );
			$quantity = intval( $quantity );
			if ( $product_id > 0 && $quantity > 0 ) {
				WC()->cart->add_to_cart($product_id, $quantity);
			}
		}

		wp_safe_redirect( wc_get_checkout_url() );
		exit;
	}
}
