<?php

namespace MagicAI_WooCommerce_Extension\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Filters {
	public function __construct() {
	}
}
