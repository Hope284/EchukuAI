<?php

namespace MagicAI_WooCommerce_Extension\Hooks;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Hooks {
	public function __construct() {
		new Actions();
		new Filters();
	}
}
