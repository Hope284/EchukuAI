<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

use Booking_Hub\Helpers\Icon;

final class MagicAI_WooCommerce_Extension {
	private static mixed $_instance = null;

	public static function instance(): MagicAI_WooCommerce_Extension {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;
	}

	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ] );
	}

	public function i18n(): void {
		load_plugin_textdomain( 'magicai-woocommerce-extension' );
	}

	public function on_plugins_loaded(): void {
		if ( $this->is_compatible() ) {
			$this->init();
		}
	}

	public function is_compatible(): bool {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action(
				'admin_notices',
				function () {
					$message = sprintf(
					/* translators: 1: Plugin name 2: Booking Hub */
						esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'magicai-woocommerce-extension' ),
						'<strong>' . esc_html__( 'DZEVA WooCommerce Extension', 'magicai-woocommerce-extension' ) . '</strong>',
						'<strong>' . esc_html__( 'WooCommerce', 'magicai-woocommerce-extension' ) . '</strong>'
					);
					printf( '<div class="bhub-admin-notice bhub-admin-notice--warning"><p>%1$s</p></div>', $message );
				}
			);

			return false;
		}

		return true;
	}

	public function init(): void {
		do_action( 'magicai_woocommerce_extension_init' );
		$this->i18n();
		$this->include_files();
		do_action( 'magicai_woocommerce_extension_loaded' );
	}

	public function include_files(): void {
		new \MagicAI_WooCommerce_Extension\Hooks\Hooks();
	}
}

MagicAI_WooCommerce_Extension::instance();
