<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

spl_autoload_register(
	function ( $class ) {
		$base_dir = MAGICAI_WOOCOMMERCE_EXTENSION_PATH . 'includes/';

		$namespace = 'MagicAI_WooCommerce_Extension\\';
		$len       = strlen( $namespace );

		if ( strncmp( $namespace, $class, $len ) !== 0 ) {
			return;
		}

		$relative_class = substr( $class, $len );
		$file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

		if ( file_exists( $file ) ) {
			require_once $file;
		}
	}
);
