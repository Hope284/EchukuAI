<?php
/**
 * Plugin Name: DZEVA WooCommerce Extension
 * Description: An extension to integrate DZEVA features with WooCommerce.
 * Plugin URI: https://dzeva.com/
 * Version: 1.0.0
 * Author: ECHUKU
 * Author URI: https://dzeva.com/
 * Text Domain: magicai-woocommerce-extension
 * Requires PHP: 8.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MAGICAI_WOOCOMMERCE_EXTENSION_NAME', 'magicai_woocommerce_extension' );
define( 'MAGICAI_WOOCOMMERCE_EXTENSION_PATH', plugin_dir_path( __FILE__ ) );
define( 'MAGICAI_WOOCOMMERCE_EXTENSION_URL', plugin_dir_url( __FILE__ ) );
define( 'MAGICAI_WOOCOMMERCE_EXTENSION_VERSION', get_file_data( __FILE__, array( 'Version' => 'Version' ), false )['Version'] );

require_once MAGICAI_WOOCOMMERCE_EXTENSION_PATH . 'includes/autoloader.php';
require_once MAGICAI_WOOCOMMERCE_EXTENSION_PATH . 'includes/plugin.php';

register_activation_hook(
	__FILE__,
	function () {
		flush_rewrite_rules();
	}
);

register_deactivation_hook(
	__FILE__,
	function () {
		flush_rewrite_rules();
	}
);
